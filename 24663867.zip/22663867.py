def reemplazar_simbolo(w: str, a: str, b: str) -> str:
    """
    La funcion busca las ocurrencias del valor a recursivamente, cambia el
    valor de a por b y revisa si es que existe otra, hasta que no encuentre
    ninguna, en ese caso devuelve la cadena con todas las ocurrencias de a 
    como b.
    """

    if w.find(a) != -1:
        w = w[:w.find(a)] + b + w[w.find(a) + 1:]
        if w.find(a) != -1:
            return reemplazar_simbolo(w, a, b)    
    return w


w = input('Ingrese el valor de w\n')
a = input('Ingrese el valor de a\n')
b = input('Ingrese el valor de b\n')

w = reemplazar_simbolo(w, a, b)
print('Su nueva palabra es:\n'+w)